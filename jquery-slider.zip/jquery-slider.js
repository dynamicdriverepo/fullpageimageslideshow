;(function($){
	var has_3d;
	var image_sizes = {};

	// these properties can be fetched from the playlist_url
	var remote_loadable = [
		"preload_images",
		"anim_fps",
		"transition_time",
		"hold_time",
		"loops"
	];

	// these are the default values
	var defaults = {
		"preload_images":-1, // preload all images
		"playlist":null,
		"playlist_url":null,
		"throbber":null,
		"anim_fps":20,
		"transition_time":2, // seconds
		"hold_time":4,
		"on_image_change":null,
		"loops":null, // number of times the images will loop
	};

	//--------------------


	function has3DTransform() {
		var div = document.createElement('div');
		var properties = ['perspectiveProperty', 'WebkitPerspective'];
		div.id = '_test_div_';

		for (var i = properties.length - 1; i >= 0; i--){
			if (div.style[properties[i]] != undefined) {
				var st = document.createElement('style');
				st.textContent = '@media (-webkit-transform-3d){#_test_div_{height:3px}}';
				document.getElementsByTagName('head')[0].appendChild(st);
				document.body.appendChild(div);
				has_3d = (div.offsetHeight === 3);
				st.parentNode.removeChild(st);
				div.parentNode.removeChild(div);
				if (has_3d) return has_3d;
			}
		}
		return false;
	}


	function getImage(img_url, on_ready) {
		var $img = $('<img>');
		$img.load(function() {
				var img = this;
				setTimeout(function() {
					on_ready($img, img.width, img.height);
				}, 1);
		});
		$img.attr({ src: img_url});
	}


	function preload(img_list, on_ready) {
		var to_load = img_list.length;
		
		$.each(img_list, function(index, img_url) {
			var $img = $("<img>");
			$img.load(function() {
				var img = this;
				to_load--;
				if (to_load == 0) {
					if (on_ready != null) setTimeout(on_ready, 1);
				}
			});
			$img.attr({ src: img_url});
		});
	}

	function getProp(obj, prop, def) {
		if (obj.hasOwnProperty(prop)) {
			return(obj[prop]);
		} else {
			return def;
		}
	}

	//----------------------

	function panelObject($display_node) {
		var img_w = 0;
		var img_h = 0;
		var tx = 0;
		var ty = 0;
		var scale = 1;

		var vp_scale = 1;

		var from_x;
		var from_y;
		var from_zoom;
		var to_x;
		var to_y;
		var to_zoom;
		var url;
		var caption;

		var loading = 0;

		var now;

		var self = this;

		this.checkResize = function() {
			var $container = $display_node.parent();
			width = $container.width();
			height = $container.height();
			var vp_aspect = width / (height<1?1:height);
			var p_aspect;


			p_aspect = img_w / (img_h<1?1:img_h);

			if (vp_aspect > p_aspect) {
				vp_scale = width / (img_w<1?1:img_w);
			} else {
				vp_scale = height / (img_h<1?1:img_h);
			}

			if (vp_scale < 1) vp_scale = 1;
	
			vp_scale *= 1;//.1;
			
			this.transform(tx, ty, scale);
		}

		this.loadImage = function(img_url, transition, _caption) {
			loading++;
			url = img_url;
			caption = _caption;
			getImage(img_url, function ($img, _img_w, _img_h) {
				$display_node.css("background-image","url("+img_url+")");
				img_w = _img_w;
				img_h = _img_h;
				if (transition==null)
					self.randomTransition();
				else
					self.customTransition(transition);
				self.checkResize();
				loading--;
			});
		}

		this.getImageUrl = function() {
			return url;
		}

		this.getImageCaption = function() {
			return caption?caption:"";
		}

		var transform2d = function(px, py, _scale) {
			scale = _scale;
			_scale *= vp_scale;
			var mtx = "matrix("+_scale+",0,0,"+_scale+","+px+","+py+")";
			$display_node.css("transform",mtx).css("-ms-transform",mtx).css("-webkit-transform",mtx);
		}

		var transform3d = function(px, py, _scale) {
			scale = _scale;
			_scale *= vp_scale;
			var mtx = "matrix3d("+_scale+",0,0,0,0,"+_scale+",0,0,0,0,1,0,"+px+","+py+",0,1)";
			$display_node.css("transform",mtx).css("-ms-transform",mtx).css("-webkit-transform",mtx);
		}


		this.transform =  has_3d ? transform3d : transform2d;


		this.setTransition = function(_from_x, _from_y, _from_zoom, _to_x, _to_y, _to_zoom) {
			from_x = _from_x;
			from_y = _from_y;
			from_zoom = _from_zoom;
			to_x = _to_x;
			to_y = _to_y;
			to_zoom = _to_zoom;
		}

		this.setTransitionPos = function(t) {
			this.transform(
					(to_x-from_x) * t + from_x,
					(to_y-from_y) * t + from_y,
					(to_zoom-from_zoom) * t + from_zoom);
		}

		this.randomTransition = function() {
			var s1, s2, x1, y1, x2, y2;

			if (has_3d) {
				s1 = Math.random()*0.5 + 1.0;
				s2 = Math.random()*0.5 + 1.0;
				x1 = (Math.random()-0.5)*(s1-1)*img_w;
				y1 = (Math.random()-0.5)*(s1-1)*img_h;
				x2 = (Math.random()-0.5)*(s2-1)*img_w;
				y2 = (Math.random()-0.5)*(s2-1)*img_h;
			} else {
				var s = Math.random();
				s1 = s2 = Math.random()*0.5 + 1.2;
				x1 = y1 = x2 = y2 = 0;
				if (s < 0.3333) {
					if (s < 0.166667) {
						s2 = s1 + Math.random()*0.2;
					} else {
						s1 = s2 + Math.random()*0.2;
					}
				} else if (s < 0.6666) {
					x1 = (Math.random()-0.5)*(s1-1)*img_w;
					x2 = (Math.random()-0.5)*(s2-1)*img_w;
				} else {
					y1 = (Math.random()-0.5)*(s1-1)*img_h;
					y2 = (Math.random()-0.5)*(s2-1)*img_h;
				}
			}

			self.setTransition(x1,y1,s1, x2,y2,s2);
		}

		this.customTransition = function(tr) {
			var s1, s2, x1, y1, x2, y2;
			var w2 = img_w / 2;
			var h2 = img_h / 2;

			x1 = -getProp(tr,'x1',w2) + w2;
			y1 = -getProp(tr,'y1',h2) + h2;
			x2 = -getProp(tr,'x2',w2) + w2;
			y2 = -getProp(tr,'y2',h2) + h2;

			s1 = getProp(tr,'z1',1);
			s2 = getProp(tr,'z2',1);

			// make sure the zoom is adequate for the given coordinates
			s1 = Math.max( s1, 2*Math.max(Math.abs(x1)/img_w, Math.abs(y1)/img_h)+1)
			s2 = Math.max( s2, 2*Math.max(Math.abs(x2)/img_w, Math.abs(y2)/img_h)+1)

			x1 *= s1-1;
			y1 *= s1-1;

			x2 *= s2-1;
			y2 *= s2-1;

			if (!has_3d) {
				// reduce to only one movement (panning or zooming)... try to guess
				// which is more appropriate
				var hint = getProp(tr,'hint','auto')
				switch (hint) {
					case "zoom": case "hpan": case "vpan": break;
					default:
						var s = (s1>s2 ? s1/s2 : s2/s1)-1;
						var x = Math.abs(x2-x1) / img_w;
						var y = Math.abs(y2-y1) / img_h;

						if (s > x) {
							if (s > y) {
								hint = "zoom";
							} else {
								hint = "vpan";
							}
						} else { 
							if (x > y) {
								hint = "hpan";
							} else {
								hint = "vpan";
							}
						}
					
				}

				switch (hint) {
					case "zoom":
						if (s1 < s2) { // zoom out
							x2 = x1; y2 = y1;
						} else { // zoom in
							x1 = x2; y1 = y2;
						} break;
					case "hpan":
						if (s1 < s2) {
							y2 = y1; s1 = s2;
						} else {
							y1 = y2; s2 = s1;
						} break;
					case "vpan":
						if (s1 < s2) {
							x2 = x1; s1 = s2;
						} else {
							x1 = x2; s2 = s1;
						} break;
				}
			}

			self.setTransition(x1,y1,s1, x2,y2,s2);
		}

		this.setOpacity = function(op) {
			$display_node.css('opacity', op);
		}

		this.sendBack = function() {
			$display_node.removeClass("smooth_slider_panel_2").addClass("smooth_slider_panel_1");
		}

		this.sendFront = function() {
			$display_node.removeClass("smooth_slider_panel_1").addClass("smooth_slider_panel_2");
		}

		this.finishedLoading = function() {
			return loading == 0;
		}
	}

	function resizerObject($container, settings) {
		var tot_panels = 2;
		var width;
		var height;
		var self = this;
		var playlist;
		var throbber = 1;
		var tot_loaded_images = 0;
		var current_image = 0;
		var paused = false;
		var current_loop = settings['loops'];

		var ticker_var;

		var fade_time = 1;
		var anim_time = 1;


		//console.log("Fade time:",fade_time);
		//console.log("Anim time:",anim_time);

		var fade_start_time = anim_time - fade_time;

		var ticker_state = 0;
		var current_anim_time = 0;

		var finished_loading;

		self.$container = $container;

		$container.addClass("smooth_slider_container");
		$container.append('<div class="smooth_slider_panel smooth_slider_panel_1"></div>');
		$container.append('<div class="smooth_slider_panel smooth_slider_panel_2"></div>');

		var panels = [new panelObject($container.find(".smooth_slider_panel_1")), // top panel
					  new panelObject($container.find(".smooth_slider_panel_2"))]; // bottom panel


		function swapPanels() {
			var tmp = panels[0];
			panels[0] = panels[1];
			panels[1] = tmp;
			panels[0].sendFront();
			panels[1].sendBack();
		}

		function getImageList(from, to) {
			var tot_images = playlist.length;
			var img_list = [];

			if (to == -1) to = tot_images-1;
			if (to >= tot_images) to = tot_images-1;
			if (from < 0) from = 0;
			if (from > to) return [];

			for (var i = from; i <= to; i++) {
				img_list.push(playlist[i]['url']);
			}
			return img_list;
		}


		function showThrobber() {
			throbber++;
			if (throbber == 1)
				if (settings['throbber']) $(settings['throbber']).animate({"opacity": 1},400);
		}


		function hideThrobber(fast) {
			throbber--;
			if (throbber == 0) {
				if (fast)
					if (settings['throbber']) $(settings['throbber']).css("opacity",0);
				else
					if (settings['throbber']) $(settings['throbber']).animate({"opacity": 0}, 400);
			}
		}

		//----

		function loadImage(panel_num, img_id) {
			var img = playlist[img_id];
			panels[panel_num].loadImage(img['url'],
						img.hasOwnProperty('slide')?img['slide']:null,
						img.hasOwnProperty('caption')?img['caption']:null
						);
		}


		function imagesReady() {
			hideThrobber(true);
			recalcExtents();

			loadImage(0, nextImage());

			//console.log("Images ready...");

			if (settings['on_image_change']) {
				//console.log(">>>",panels[0].getImageCaption(), panels[0].getImageUrl());
				settings['on_image_change'](panels[0].getImageCaption(), panels[0].getImageUrl());
			}

			now = new Date().getTime();
			ticker_var = setInterval(ticker, 1000/settings['anim_fps']);

			// start fading the first image in
			current_anim_time = 0;//anim_time - fade_time;
		}
		
		function playlistReady() {
			fade_time = Math.round(settings['transition_time'] * 1000.0);
			anim_time = Math.round((2*settings['transition_time'] + settings['hold_time']) * 1000.0);
			fade_start_time = anim_time - fade_time;
			// now preload all the required images
			var img_list = getImageList(0,settings['preload_images']);
			tot_loaded_images = img_list.length;
			preload(img_list, imagesReady);
		}

		function nextImage() {
			var img;

			if (current_image == 0 && settings['loops']) {
				if (current_loop == 0) {
					current_loop = settings['loops']-1;
					self.pause();
				} else {
					current_loop--;
				}
			}


			if (tot_loaded_images < playlist.length) {
				var img_list = getImageList(tot_loaded_images, tot_loaded_images);
				preload(img_list, null);
				tot_loaded_images++;
			}

			img = current_image;
		
			current_image++;
			if (current_image == playlist.length)
				current_image = 0;


			console.log("Next image: ",img);

			return img

		}

		this.pause = function() {
			if (settings['on_pause']) settings['on_pause'].call(this);
			paused = true;
			console.log("Pause");
		}

		this.resume = function() {
			if (settings['on_resume']) settings['on_resume'].call(this);
			paused = false;
			console.log("Resume");
		}


		function ticker() {

			var dt = new Date().getTime() - now;
			now += dt;

			if (current_anim_time < fade_time) {
				ticker_state = 0;
				// this will only happen at the very beginning
				panels[0].setOpacity( current_anim_time / fade_time );
				panels[0].setTransitionPos( current_anim_time / anim_time);
			} else if (ticker_state == 0) { // current_anim_time == fade_time
				ticker_state = 1;
				// this is when we flip panels
				panels[0].setTransitionPos( current_anim_time / anim_time);
				panels[1].setOpacity(0); // back panel fully transparent
				panels[0].setOpacity(1); // front panel fully visible
				swapPanels(); // send front panel to the back

				console.log(panels[0].finishedLoading(), panels[1].finishedLoading())
				loadImage(0, nextImage()); // load the next image in the (hidden) front panel
			} else if (current_anim_time >= fade_start_time) {

				if (ticker_state == 1) { //current_anim_time == fade_start_time

					var fl = panels[0].finishedLoading();
					if (fl && !finished_loading) {
						hideThrobber();
					}
					if (!fl && finished_loading) {
						showThrobber();
					}
					finished_loading = fl;

					if (paused || !fl) {
						return;
					}

					ticker_state = 2;

					if (settings['on_image_change']) {
						settings['on_image_change'].call(this,panels[0].getImageCaption(), panels[0].getImageUrl());
					}
				}
				// front panel fades in
				var rel_frame = (current_anim_time - fade_start_time);
				panels[0].setTransitionPos( rel_frame / anim_time);
				panels[0].setOpacity(rel_frame / fade_time);
				panels[1].setTransitionPos( current_anim_time / anim_time);


				if (current_anim_time >= anim_time) {
					current_anim_time -= (anim_time-fade_time);
					ticker_state = 0;
				}
			} else {

				// animate back panel (front panel is hidden)
				panels[1].setTransitionPos( current_anim_time / anim_time);
			}
			current_anim_time += dt;
		}

		function recalcExtents() {
			panels[0].checkResize();
			panels[1].checkResize();
		}

		function mergeRemoteSettings(data) {
			for (i = 0; i < remote_loadable.length; i++) {
				var prop = remote_loadable[i];
				if (data.hasOwnProperty(prop)) {
					settings[prop] = data[prop];
					console.log(prop,'->',data[prop]);
				}
			}
		}


		//----


		$(window).resize(recalcExtents);


		finished_loading = true;

		swapPanels();

		panels[0].setOpacity(0);
		panels[1].setOpacity(0);
	

		// if we need to load the playlist from the server do so
		if (settings.playlist_url) {
			$.getJSON(settings.playlist_url, null, function(data, textStatus, jqXHR) {
				//console.log(data);
				playlist = data['playlist'];
				mergeRemoteSettings(data);
				playlistReady();
			});
		} else {
			playlist = settings['playlist'];
			playlistReady();
		}

	}

	//----------------------

	$.fn.smoothslider = function(action, options) {
		var settings = $.extend({}, defaults, options);

		switch(action) {
			case "install":
				has_3d = has3DTransform();
				return this.each(function() {
					var obj = new resizerObject($(this), settings);

					obj.$container.data("smoothslider",obj);
				});
				break;
			case "resume":
				return this.each(function() {
					var $this = $(this);
					$this.data("smoothslider").resume();
				});
				break;
			case "pause":
				return this.each(function() {
					var $this = $(this);
					$this.data("smoothslider").pause();
				});
				break;
				
		}
	}
})(jQuery);

(function($){
 	$.fn.extend({
 		fade_swap: function(text, time, easing) {
			if (time === undefined) time = 1000;
			if (easing === undefined) easing = "swing";

    		return this.each(function() {
				var $area = $(this);
				$area.animate({"opacity": 0}, time, easing, function() {
					$area.text(text);
					$area.animate({"opacity": 1}, time, easing);
				});
			});
		}
	});
})(jQuery);
